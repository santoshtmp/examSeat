function studetail() {
	// body...
	//document.write("Hello World!");

	location.href='userDetail.php';

}