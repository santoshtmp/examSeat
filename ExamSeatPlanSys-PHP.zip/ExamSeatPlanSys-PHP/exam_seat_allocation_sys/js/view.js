
function generate(id) {

	location.href='generateAtten.php?id='+id+'';
}