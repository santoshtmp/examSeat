   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

 <style type="text/css">
	          	
  .ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    
    background-color: #3C9ED9;
   /* position: fixed;
    width: 100%;
    top: 0px;
    margin-bottom: 20px;*/

    }

 .li{
      display: block;
      font-size: 30px;
      text-align: center;
      color: white;
  
    }

  #a{
      display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 20px;
    } 

 
 </style>


  <ul class="ul">
      <li class="li" ><a type="a"  href="index.php " style="color: white;">Exam Seat Allocation System </a></li>  
   </ul>

  